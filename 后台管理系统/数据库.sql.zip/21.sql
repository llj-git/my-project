prompt PL/SQL Developer import file
prompt Created on 2020��8��1�� by LLJ
set feedback off
set define off
prompt Disabling triggers for MEMBER...
alter table MEMBER disable all triggers;
prompt Disabling triggers for PRODUCT...
alter table PRODUCT disable all triggers;
prompt Disabling triggers for ORDERS...
alter table ORDERS disable all triggers;
prompt Disabling triggers for TRAVELLER...
alter table TRAVELLER disable all triggers;
prompt Disabling triggers for ORDER_TRAVELLER...
alter table ORDER_TRAVELLER disable all triggers;
prompt Disabling triggers for PERMISSION...
alter table PERMISSION disable all triggers;
prompt Disabling triggers for PERSON...
alter table PERSON disable all triggers;
prompt Disabling triggers for ROLE...
alter table ROLE disable all triggers;
prompt Disabling triggers for ROLE_PERMISSION...
alter table ROLE_PERMISSION disable all triggers;
prompt Disabling triggers for SYSLOG...
alter table SYSLOG disable all triggers;
prompt Disabling triggers for USERS...
alter table USERS disable all triggers;
prompt Disabling triggers for USERS_ROLE...
alter table USERS_ROLE disable all triggers;
prompt Disabling foreign key constraints for ORDERS...
alter table ORDERS disable constraint SYS_C005427;
alter table ORDERS disable constraint SYS_C005428;
prompt Disabling foreign key constraints for ORDER_TRAVELLER...
alter table ORDER_TRAVELLER disable constraint SYS_C005431;
alter table ORDER_TRAVELLER disable constraint SYS_C005432;
prompt Disabling foreign key constraints for ROLE_PERMISSION...
alter table ROLE_PERMISSION disable constraint SYS_C005442;
alter table ROLE_PERMISSION disable constraint SYS_C005443;
prompt Disabling foreign key constraints for USERS_ROLE...
alter table USERS_ROLE disable constraint SYS_C005438;
alter table USERS_ROLE disable constraint SYS_C005439;
prompt Deleting USERS_ROLE...
delete from USERS_ROLE;
commit;
prompt Deleting USERS...
delete from USERS;
commit;
prompt Deleting SYSLOG...
delete from SYSLOG;
commit;
prompt Deleting ROLE_PERMISSION...
delete from ROLE_PERMISSION;
commit;
prompt Deleting ROLE...
delete from ROLE;
commit;
prompt Deleting PERSON...
delete from PERSON;
commit;
prompt Deleting PERMISSION...
delete from PERMISSION;
commit;
prompt Deleting ORDER_TRAVELLER...
delete from ORDER_TRAVELLER;
commit;
prompt Deleting TRAVELLER...
delete from TRAVELLER;
commit;
prompt Deleting ORDERS...
delete from ORDERS;
commit;
prompt Deleting PRODUCT...
delete from PRODUCT;
commit;
prompt Deleting MEMBER...
delete from MEMBER;
commit;
prompt Loading MEMBER...
insert into MEMBER (id, name, nickname, phonenum, email)
values ('E61D65F673D54F68B0861025C69773DB', '����', 'С��', '18888888888', 'zs@163.com');
commit;
prompt 1 records loaded
prompt Loading PRODUCT...
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values ('676C5BD1D35E429A8C2E114939C5685A', 'itcast-002', '����������', '����', to_timestamp('10-10-2018 10:10:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1200, '����������', 1);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values ('12B7ABF2A4C544568B0A7C69F36BF8B7', 'itcast-003', '�Ϻ�������', '�Ϻ�', to_timestamp('25-04-2018 14:30:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1800, 'ħ��������', 0);
insert into PRODUCT (id, productnum, productname, cityname, departuretime, productprice, productdesc, productstatus)
values ('9F71F01CB448476DAFB309AA6DF9497F', 'itcast-001', '����������', '����', to_timestamp('10-10-2018 10:10:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 1200, '����������', 1);
commit;
prompt 3 records loaded
prompt Loading ORDERS...
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('0E7231DC797C486290E8713CA3C6ECCC', '12345', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '676C5BD1D35E429A8C2E114939C5685A', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('5DC6A48DD4E94592AE904930EA866AFA', '54321', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '676C5BD1D35E429A8C2E114939C5685A', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('2FF351C4AC744E2092DCF08CFD314420', '67890', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '12B7ABF2A4C544568B0A7C69F36BF8B7', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('A0657832D93E4B10AE88A2D4B70B1A28', '98765', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '12B7ABF2A4C544568B0A7C69F36BF8B7', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('E4DD4C45EED84870ABA83574A801083E', '11111', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '12B7ABF2A4C544568B0A7C69F36BF8B7', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('96CC8BD43C734CC2ACBFF09501B4DD5D', '22222', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '12B7ABF2A4C544568B0A7C69F36BF8B7', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('55F9AF582D5A4DB28FB4EC3199385762', '33333', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '9F71F01CB448476DAFB309AA6DF9497F', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('CA005CF1BE3C4EF68F88ABC7DF30E976', '44444', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '9F71F01CB448476DAFB309AA6DF9497F', 'E61D65F673D54F68B0861025C69773DB');
insert into ORDERS (id, ordernum, ordertime, peoplecount, orderdesc, paytype, orderstatus, productid, memberid)
values ('3081770BC3984EF092D9E99760FDABDE', '55555', to_timestamp('02-03-2018 12:00:00.000000', 'dd-mm-yyyy hh24:mi:ss.ff'), 2, 'ûʲô', 0, 1, '9F71F01CB448476DAFB309AA6DF9497F', 'E61D65F673D54F68B0861025C69773DB');
commit;
prompt 9 records loaded
prompt Loading TRAVELLER...
insert into TRAVELLER (id, name, sex, phonenum, credentialstype, credentialsnum, travellertype)
values ('3FE27DF2A4E44A6DBC5D0FE4651D3D3E', '����', '��', '13333333333', 0, '123456789009876543', 0);
insert into TRAVELLER (id, name, sex, phonenum, credentialstype, credentialsnum, travellertype)
values ('EE7A71FB6945483FBF91543DBE851960', '��С��', '��', '15555555555', 0, '987654321123456789', 1);
commit;
prompt 2 records loaded
prompt Loading ORDER_TRAVELLER...
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('0E7231DC797C486290E8713CA3C6ECCC', '3FE27DF2A4E44A6DBC5D0FE4651D3D3E');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('2FF351C4AC744E2092DCF08CFD314420', '3FE27DF2A4E44A6DBC5D0FE4651D3D3E');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('3081770BC3984EF092D9E99760FDABDE', 'EE7A71FB6945483FBF91543DBE851960');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('55F9AF582D5A4DB28FB4EC3199385762', 'EE7A71FB6945483FBF91543DBE851960');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('5DC6A48DD4E94592AE904930EA866AFA', '3FE27DF2A4E44A6DBC5D0FE4651D3D3E');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('96CC8BD43C734CC2ACBFF09501B4DD5D', 'EE7A71FB6945483FBF91543DBE851960');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('A0657832D93E4B10AE88A2D4B70B1A28', '3FE27DF2A4E44A6DBC5D0FE4651D3D3E');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('CA005CF1BE3C4EF68F88ABC7DF30E976', 'EE7A71FB6945483FBF91543DBE851960');
insert into ORDER_TRAVELLER (orderid, travellerid)
values ('E4DD4C45EED84870ABA83574A801083E', 'EE7A71FB6945483FBF91543DBE851960');
commit;
prompt 9 records loaded
prompt Loading PERMISSION...
insert into PERMISSION (id, permissionname, url)
values ('AD6A7EEBB0734E1B81D103AF5F41EDDB', 'user findAll', '/user/findAll.do');
insert into PERMISSION (id, permissionname, url)
values ('5A43F88E03434CB8B07AACD34DBDE852', 'user findById', '/user/findById.do');
commit;
prompt 2 records loaded
prompt Loading PERSON...
insert into PERSON (pid, pname)
values (1, 'С��');
commit;
prompt 1 records loaded
prompt Loading ROLE...
insert into ROLE (id, rolename, roledesc)
values ('1111', 'ADMIN', 'vip');
insert into ROLE (id, rolename, roledesc)
values ('2222', 'USER', 'vip');
commit;
prompt 2 records loaded
prompt Loading ROLE_PERMISSION...
insert into ROLE_PERMISSION (permissionid, roleid)
values ('5A43F88E03434CB8B07AACD34DBDE852', '1111');
insert into ROLE_PERMISSION (permissionid, roleid)
values ('AD6A7EEBB0734E1B81D103AF5F41EDDB', '1111');
commit;
prompt 2 records loaded
prompt Loading SYSLOG...
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('AC6C6A6CC91E46629DC4D4B82F47FC8A', to_timestamp('01-08-2020 18:33:54.245000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 26, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('21410BC2CDEB438396CE7A8367C97EA5', to_timestamp('01-08-2020 18:33:56.195000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/sysLog/findAll.do', 70, '[����] com.llj.controller.SysLogController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('B69584263BE945F08229406B5BA8A881', to_timestamp('01-08-2020 18:34:02.133000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/product/findAll.do', 48, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('BEEF6D03E138430287B9FFDEE7121B9D', to_timestamp('01-08-2020 18:34:04.210000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/sysLog/findAll.do', 3, '[����] com.llj.controller.SysLogController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('4A2D869FCD8F400E8B4D1440D4C50E7F', to_timestamp('01-08-2020 18:39:16.998000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 22, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('5A6819DF4DF1400D9BD0B2D2508E011B', to_timestamp('01-08-2020 18:39:30.405000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/product/findAll.do', 48, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('9ABC23A6A785421DB32587C5A9B89F57', to_timestamp('01-08-2020 18:39:39.466000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/product/findAll.do', 6, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('50995228A7FB48AA97186BD1CC74A949', to_timestamp('01-08-2020 20:00:09.133000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/role/findAll.do', 25, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('1DFE8031371A4D21AD26111DF64335E0', to_timestamp('01-08-2020 20:00:15.778000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 12, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('53FA09C793104AAEAB4A96F026A5A810', to_timestamp('01-08-2020 20:00:18.054000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/role/findAll.do', 2, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('4CABDC97B744479DA7BA9CED597B78D4', to_timestamp('01-08-2020 20:00:41.799000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/role/findAll.do', 2, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('D5F3292164704D6CAFF3DB8A312AA73B', to_timestamp('01-08-2020 20:01:31.246000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 10, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('A1BCA7B8310A4B83ABB4E1EC5E8C9C63', to_timestamp('01-08-2020 20:40:24.540000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 4, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('A65BCC7FAD0A4DA4B95C5D330C1D3E40', to_timestamp('01-08-2020 20:40:28.679000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 8, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('485436A4D79D4777910B64F06F4396DD', to_timestamp('01-08-2020 20:40:29.933000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 7, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('CEDED172284745A09A2072205AE9A278', to_timestamp('01-08-2020 20:40:31.478000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 6, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('AEB58BF053874EC983ECCE9888142C8F', to_timestamp('01-08-2020 20:40:32.838000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 6, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('57B096FB2B674460BFCD3E783455F26C', to_timestamp('01-08-2020 20:40:40.163000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 4, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('1DB89EC45CC94A668E1D1365EFC45400', to_timestamp('01-08-2020 20:41:45.584000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 5, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('A2B88EDCB668482EB0ADD7829B8179DD', to_timestamp('01-08-2020 20:41:47.454000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 9, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('49E22285175F483D865427552EA2ACF3', to_timestamp('01-08-2020 20:41:48.772000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 8, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('7AA5ECAEE7934199BDD205C6FFF4CC4D', to_timestamp('01-08-2020 20:41:50.162000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 8, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('B9DBBE36CBDB468297829B3C80C32CF0', to_timestamp('01-08-2020 19:27:39.584000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/role/findAll.do', 11, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('8B5C73751C60408CA67964681B801548', to_timestamp('01-08-2020 19:29:09.234000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/role/findAll.do', 2, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('C9A34457233E40A5B7837F101E6E4A44', to_timestamp('01-08-2020 19:53:52.384000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 9, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('362A3EC145D94DA7B3146735BB2E6FD7', to_timestamp('01-08-2020 19:53:55.259000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'tom', '0:0:0:0:0:0:0:1', '/role/findAll.do', 8, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('8ABE4144A55F44058E903C366487044D', to_timestamp('01-08-2020 20:35:57.659000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 27, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('BD4958900393458A83A27ABFDF1F9C5B', to_timestamp('01-08-2020 20:35:59.414000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 12, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('FC6522C28ED446E5B65BF40F35E37BC3', to_timestamp('01-08-2020 20:38:26.576000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 19, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('01B4452854E240A8988B9BD52E223D92', to_timestamp('01-08-2020 20:38:23.032000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 3, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('6ADE133E0F2D4597B4153059F885E6B7', to_timestamp('01-08-2020 20:38:24.973000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 12, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('9AAB5020C9264CCC93287FCFDA5808CA', to_timestamp('01-08-2020 20:38:28.265000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 7, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('46EDA612083A47F3AA9C916DBD9B8BF3', to_timestamp('01-08-2020 20:38:30.111000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 9, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('5CCC9B563A5D4E44A66C0725AF97B654', to_timestamp('01-08-2020 20:38:32.215000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 8, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('1F8548DA7B6342379B1ED451F992C6AB', to_timestamp('01-08-2020 20:38:34.488000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 10, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('093E29DA36BB4F3C8DE089894A50CA87', to_timestamp('01-08-2020 20:39:27.502000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 10, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('1C231BF7905B46F0A4D942F88197CF1E', to_timestamp('01-08-2020 20:39:29.224000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 6, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('40C3FADCADA044B8B8A129D980E69AC7', to_timestamp('01-08-2020 20:39:35.215000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 3, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('5786BCF45C334A20955DE22E6226133E', to_timestamp('01-08-2020 20:39:37.142000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 2, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('EB6195486A564C8A8AFC3C89ADB13878', to_timestamp('01-08-2020 20:39:42.896000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 10, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('24B135163FE14F1D8F9CDBE887755BA3', to_timestamp('01-08-2020 20:39:45.191000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 6, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('46958680FE4B4830955E6B67A52FB364', to_timestamp('01-08-2020 20:40:01.310000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 9, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('9EA14CEC00184E39A4E2F7BCA3FFF076', to_timestamp('01-08-2020 20:40:06.854000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 7, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('E9F40322B3AC49EEAF3F65FCEA12EF72', to_timestamp('01-08-2020 20:40:09.469000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 7, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('4C075AB0361C42EC98463CFE77656791', to_timestamp('01-08-2020 20:40:10.986000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/orders/findAll.do', 5, '[����] com.llj.controller.OrdersController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('7348206E028D4FA79981AFCEF9E16DD8', to_timestamp('01-08-2020 20:48:12.601000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 24, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('3F91BE42CF59435987AC1EFE90546F71', to_timestamp('01-08-2020 20:48:14.625000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 14, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('9E9640F06800458385A933251389DD23', to_timestamp('01-08-2020 20:48:17.005000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 10, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('AEC1B2F3EC924E079FC7D7A461C2F413', to_timestamp('01-08-2020 20:06:20.652000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 21, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('B84E4DAEBDBE429E8AB77D1F4C94C6C8', to_timestamp('01-08-2020 20:06:28.754000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 11, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('A2C63E751DEC4C9882E6847C886AA41C', to_timestamp('01-08-2020 20:06:32.775000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 3, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('25C51F2E29154193B36A6EFEA56571ED', to_timestamp('01-08-2020 20:06:43.570000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 3, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('060002A5E9774F6AA95C331F9EE670A7', to_timestamp('01-08-2020 20:06:45.279000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 3, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('A5CDFAB666CE45498E7472C4051EBD4A', to_timestamp('01-08-2020 20:06:47.480000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 7, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('320B0DB6A96846BC9A384C62CB136A08', to_timestamp('01-08-2020 20:43:54.950000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 9, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('6A9E00DF38E4482DA6CE3638D2CC451D', to_timestamp('01-08-2020 20:43:56.959000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 12, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('363F25824C784B1FAA11236D4FF0D027', to_timestamp('01-08-2020 20:43:53.271000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/user/findAll.do', 8, '[����] com.llj.controller.UserController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('A2BB5E22664C443BB51A1BCBFBEB02B9', to_timestamp('01-08-2020 20:07:00.438000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/role/findAll.do', 2, '[����] com.llj.controller.RoleController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('9A17792836954CB2AF183A6599D27FCE', to_timestamp('01-08-2020 20:07:02.247000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/permission/findAll.do', 2, '[����] com.llj.controller.PermissionController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('5AE6FAFCE5C64594A8BE021F0239F2C3', to_timestamp('01-08-2020 20:44:01.053000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 3, '[����] com.llj.controller.ProductController[������] findAll');
insert into SYSLOG (id, visittime, username, ip, url, executiontime, method)
values ('97E23676D46E4688938A46A670BF1328', to_timestamp('01-08-2020 20:44:03.143000', 'dd-mm-yyyy hh24:mi:ss.ff'), 'llj', '0:0:0:0:0:0:0:1', '/product/findAll.do', 6, '[����] com.llj.controller.ProductController[������] findAll');
commit;
prompt 61 records loaded
prompt Loading USERS...
insert into USERS (id, email, username, password, phonenum, status)
values ('111-222', '2576180801@qq.com', 'llj', '$2a$10$xVvea.UsFAlKumRiBwd6VOmtylBzoT0AI2EU6wMnUhCY2p1ZkHYAS', '1333333', 1);
insert into USERS (id, email, username, password, phonenum, status)
values ('5ADDEA2B341B4115B740F6CC6847B5AE', '1524319150@qq.com', 'tom', '$2a$10$IWWcTIU.Fqt0mixJEu78ou/6LEVw0jLsS/xEcgQnW6nja0hmuz3Ce', '213444421', 1);
commit;
prompt 2 records loaded
prompt Loading USERS_ROLE...
insert into USERS_ROLE (userid, roleid)
values ('111-222', '1111');
insert into USERS_ROLE (userid, roleid)
values ('111-222', '2222');
insert into USERS_ROLE (userid, roleid)
values ('5ADDEA2B341B4115B740F6CC6847B5AE', '2222');
commit;
prompt 3 records loaded
prompt Enabling foreign key constraints for ORDERS...
alter table ORDERS enable constraint SYS_C005427;
alter table ORDERS enable constraint SYS_C005428;
prompt Enabling foreign key constraints for ORDER_TRAVELLER...
alter table ORDER_TRAVELLER enable constraint SYS_C005431;
alter table ORDER_TRAVELLER enable constraint SYS_C005432;
prompt Enabling foreign key constraints for ROLE_PERMISSION...
alter table ROLE_PERMISSION enable constraint SYS_C005442;
alter table ROLE_PERMISSION enable constraint SYS_C005443;
prompt Enabling foreign key constraints for USERS_ROLE...
alter table USERS_ROLE enable constraint SYS_C005438;
alter table USERS_ROLE enable constraint SYS_C005439;
prompt Enabling triggers for MEMBER...
alter table MEMBER enable all triggers;
prompt Enabling triggers for PRODUCT...
alter table PRODUCT enable all triggers;
prompt Enabling triggers for ORDERS...
alter table ORDERS enable all triggers;
prompt Enabling triggers for TRAVELLER...
alter table TRAVELLER enable all triggers;
prompt Enabling triggers for ORDER_TRAVELLER...
alter table ORDER_TRAVELLER enable all triggers;
prompt Enabling triggers for PERMISSION...
alter table PERMISSION enable all triggers;
prompt Enabling triggers for PERSON...
alter table PERSON enable all triggers;
prompt Enabling triggers for ROLE...
alter table ROLE enable all triggers;
prompt Enabling triggers for ROLE_PERMISSION...
alter table ROLE_PERMISSION enable all triggers;
prompt Enabling triggers for SYSLOG...
alter table SYSLOG enable all triggers;
prompt Enabling triggers for USERS...
alter table USERS enable all triggers;
prompt Enabling triggers for USERS_ROLE...
alter table USERS_ROLE enable all triggers;
set feedback on
set define on
prompt Done.
